console.log("**Print odd numbers from 1 to 10**");
for(let j=0;j<=10;j++){
	if(j%2==1){
		console.log(j)
	}
}
