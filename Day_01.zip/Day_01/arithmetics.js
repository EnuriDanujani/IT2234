console.log("**Mathemetical Operation**");
let x1=50,x2=10;
var add=x1+x2;
console.log("Addition: " +add);
var sub=x1-x2;
console.log("Substraction: " +sub);
var mul=x1*x2;
console.log("Mutiplication: " +mul);
var div=x1/x2;
console.log("Division: " +div);
console.log("Module: " +(x1%x2))
