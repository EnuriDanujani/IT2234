console.log("--Print numbers from 1 to 10 in reverse order--");
for(let k=10;k>=1;k--){
	console.log(k)
}
